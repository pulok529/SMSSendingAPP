@echo off
echo ===================================================
echo Pulse Dispatch Deployment Setup
echo ===================================================
echo.

:: Check Docker Installation
docker --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Docker is not installed or the Docker Desktop app is not running.
    echo Please install Docker Desktop and start it before running this script.
    echo.
    pause
    exit /b
)

:: Create environment file if missing
if not exist .env (
    echo [INFO] Creating default .env file from .env.example...
    copy .env.example .env >nul
)

:: Spin up containers
echo [INFO] Building and starting Docker containers in detached mode...
docker compose up --build -d
if %errorlevel% neq 0 (
    echo [ERROR] Docker compose failed to start the containers.
    echo check Docker logs or run details.
    echo.
    pause
    exit /b
)

echo [INFO] Waiting for the database container to initialize...
timeout /t 8 >nul

:: Seed database
echo [INFO] Setting up database schemas and seeding users/campaign templates...
docker compose exec api npm run db:seed
if %errorlevel% neq 0 (
    echo [ERROR] Database seeding failed.
    echo.
    pause
    exit /b
)

echo.
echo ===================================================
echo Pulse Dispatch is successfully deployed and running!
echo ===================================================
echo.
echo Dashboard URL:  http://localhost:3000
echo API Health URL: http://localhost:4000/api/health
echo Default Credentials:
echo   - Email:    pulak@example.com
echo   - Password: admin12345
echo.
echo Make sure to copy app-debug.apk to your Android phone to connect it.
echo ===================================================
echo.
pause
